package com.main.repository;

import com.main.vo.memberVO;

public interface IFmemberdao {

        public void insertMember(memberVO membervo)throws Exception;
}
